## Cobblemon Battle Tracks
How are people supposed to be expected to find battles engaging if there isn't any fun music to listen to? This Addon adds **(as of 1.2)** these new battle tracks:
- Wild Battles
> - *Area Zero Wild Battle Theme
- Trainer & NPC Battles
> - Wyndon Battle Tower Theme
> - *Gladion Theme
> - *Cynthia Theme
- Legendary Encounters (Requires the addon to be installed as a Datapack)
> - *Gen 5 Roaming Legendary Theme (Sub-Legendaries)
> - *Gen 7 Legendary Theme (Box Legendaries)
> - **& Ultra Beast theme for Ultra Beast encounters*
- Extras
> - Galar Gym Leader Theme (for [Cobbled Trainers](https://modrinth.com/datapack/cobblemon-trainers) Gym Leaders)
> - *HGSS Rocket Grunt Theme (for [Cobbled Trainers](https://modrinth.com/datapack/cobblemon-trainers) Team Rocket Grunts)

**Themes marked with * have intros that require [Cobblemon Intros](https://modrinth.com/mod/cobblemon-intros) to play**

[Modrinth Page](https://modrinth.com/datapack/more-cobblemon-battle-tracks)

## How To Install
This addon must be installed as a Resource Pack, with an optional Data Pack installation giving certain Pokémon different themes

Resource Pack:
- In Minecraft, go into `[Options]`
- Click on `[Resource Packs]`
- Drag and drop the Battle Tracks .zip file into the resource packs page OR Press `[Open Pack Folder]` and place it there
- Activate the resource pack in-game

Data Pack (Optional):
- When creating your Minecraft world, press `[More]`
- Select `[Data Packs]`
- Drag and drop the Battle Tracks .zip file into the data packs page OR press `[Open Pack Folder]` and place it there
- Activate the data pack in-game

*OR*

- For existing worlds, select the world and press `[Edit]`
- Select `[Open World Folder]`
- Navigate to the folder called `[datapacks]` (should be near the top)
- Drag and drop the Battle Tracks .zip file into the folder (no data pack activation needed!)

## Project Members
- [Instrafe](https://gitlab.com/instrafe)

## License
This project is licensed under the MIT License. In summary, you are allowed to make and distribute forks of this project, so long as credit is given